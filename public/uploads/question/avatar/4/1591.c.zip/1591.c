#include <stdio.h>
#include <string.h>

int hist[255];
int array[1024][1024];

int main(void) {
	int T;
	scanf("%d\n", &T);
	while(T--) {
		int i, j, L, C;
		scanf("%d %d\n", &L, &C);
		memset(hist, 0, sizeof hist);
		for(i = 0; i < L; ++i) {
			for(j = 0; j < C; ++j) {
				scanf("%c", &array[i][j]);
				hist[array[i][j]]++;
			}
			getchar();
		}

		int N;
		scanf("%d\n", &N);
		while(N--) {
			char word[100005];
			scanf("%s\n", word);
			int k, size = strlen(word);
			if(size == 1) {
				printf("%d\n", hist[word[0]]);	
				continue;
			}

			int count = 0, aux;
			if(size <= C) {
			for(i = 0; i < L; ++i) {
				for(j = k = aux = 0; j < C; ++j) {
					if(word[k] == array[i][j]) {
						++k;
						if(k == size) {
							j = j - k + 1;
							k = 0;
							++count;
						}
					} else {
						k = 0;
					}
				}
			}
			}

			if(size <= L) {
			for(i = 0; i < C; ++i) {
				for(j = k = 0; j < L; ++j) {
					if(word[k] == array[j][i]) {
						++k;
						if(k == size) {
							j = j - k + 1;
							k = 0;
							++count;
						}
					} else {
						k = 0;
					}
				}
			}
			}

			printf("%d\n", count);
		}
		
	}

	return 0;
}
